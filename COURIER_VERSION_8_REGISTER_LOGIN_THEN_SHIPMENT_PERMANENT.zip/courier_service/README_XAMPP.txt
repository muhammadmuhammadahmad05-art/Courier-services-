COURIER SERVICE — FINAL XAMPP VERSION

What changed:
1. Customer interface no longer contains Operations Dashboard, statistics, or Recent Shipments.
2. Customer starts directly at Create New Shipment.
3. After submission, the customer sees only the status and tracking ID of the shipment created in that browser session.
4. Customer cannot access the admin shipment list or change status.
5. Admin login is available at /admin.php.
6. Admin sees every shipment and every tracking ID.
7. Admin can change status: Pending, In Transit, Delivered.
8. Admin can delete shipments.
9. New shipments are automatically Pending; the customer cannot choose an initial status.

XAMPP setup:
- Copy courier_service to C:\xampp\htdocs\
- Start Apache and MySQL
- Open phpMyAdmin and import database/courier_service.sql
- Visit http://localhost/courier_service/
- Admin: http://localhost/courier_service/admin.php

Demo admin:
Email: muhammadmuhammad@gmail.com
Password: password

Important:
Change the demo admin password before any real deployment. This project is intended for local development/testing.

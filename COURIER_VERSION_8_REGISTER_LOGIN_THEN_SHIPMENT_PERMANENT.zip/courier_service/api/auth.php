<?php
declare(strict_types=1);
require_once __DIR__.'/db.php';
$method=$_SERVER['REQUEST_METHOD'];
if($method==='GET'){ json_response(['success'=>true,'logged_in'=>!empty($_SESSION['admin']),'admin'=>$_SESSION['admin']??null]); }
if($method!=='POST') json_response(['success'=>false,'message'=>'Method not allowed.'],405);
$data=json_decode(file_get_contents('php://input')?:'{}',true); $data=is_array($data)?$data:[];
if(($data['action']??'')==='logout'){ $_SESSION=[]; if(ini_get('session.use_cookies')){ $p=session_get_cookie_params(); setcookie(session_name(),'',['expires'=>time()-42000,'path'=>$p['path'],'domain'=>$p['domain'],'secure'=>$p['secure'],'httponly'=>$p['httponly'],'samesite'=>'Lax']); } session_destroy(); json_response(['success'=>true]); }
$email=strtolower(trim((string)($data['email']??''))); $password=(string)($data['password']??'');
if($email===''||$password==='') json_response(['success'=>false,'message'=>'Email and password are required.'],422);
$stmt=$pdo->prepare('SELECT id,full_name,email,password_hash,role FROM admins WHERE email=? LIMIT 1'); $stmt->execute([$email]); $admin=$stmt->fetch();
if(!$admin || !password_verify($password,$admin['password_hash'])) json_response(['success'=>false,'message'=>'Invalid admin email or password.'],401);
unset($admin['password_hash']); $_SESSION['admin']=$admin; session_regenerate_id(true); json_response(['success'=>true,'admin'=>$admin]);

<?php
declare(strict_types=1);
require_once __DIR__.'/db.php';
$method=$_SERVER['REQUEST_METHOD'];
function input():array{ $d=json_decode(file_get_contents('php://input')?:'{}',true); return is_array($d)?$d:[]; }
function new_tracking():string{ return 'SD-'.strtoupper(bin2hex(random_bytes(4))); }
if($method==='POST'){
 if(empty($_SESSION['customer_id'])) json_response(['success'=>false,'message'=>'Please register an account and sign in before creating a shipment.'],401);
 $d=input(); $required=['first_name','last_name','phone','country','state','city','delivery_address'];
 foreach($required as $f) if(trim((string)($d[$f]??''))==='') json_response(['success'=>false,'message'=>ucwords(str_replace('_',' ',$f)).' is required.'],422);
 do{$tracking=new_tracking();$q=$pdo->prepare('SELECT id FROM shipments WHERE tracking_id=?');$q->execute([$tracking]);}while($q->fetch());
 $customerId=(int)$_SESSION['customer_id'];
 $q=$pdo->prepare('SELECT id FROM customers WHERE id=? LIMIT 1'); $q->execute([$customerId]); if(!$q->fetch()){ unset($_SESSION['customer_id'],$_SESSION['customer_email']); json_response(['success'=>false,'message'=>'Your account session has expired. Please sign in again.'],401); }
 $token=bin2hex(random_bytes(32));
 $stmt=$pdo->prepare('INSERT INTO shipments (tracking_id,customer_token,customer_id,first_name,last_name,phone,country,state,city,delivery_address,notes,status) VALUES (?,?,?,?,?,?,?,?,?,?,?,\'Pending\')');
 $stmt->execute([$tracking,$token,$customerId,trim($d['first_name']),trim($d['last_name']),trim($d['phone']),trim($d['country']),trim($d['state']),trim($d['city']),trim($d['delivery_address']),trim((string)($d['notes']??''))]);
 json_response(['success'=>true,'message'=>'Shipment created successfully.','tracking_id'=>$tracking,'status'=>'Pending']);
}
if($method==='GET'){
 $admin=require_admin();
 $q=trim((string)($_GET['q']??''));
 if($q!==''){$like='%'.$q.'%';$stmt=$pdo->prepare('SELECT * FROM shipments WHERE tracking_id LIKE ? OR first_name LIKE ? OR last_name LIKE ? OR phone LIKE ? OR city LIKE ? ORDER BY created_at DESC');$stmt->execute([$like,$like,$like,$like,$like]);}
 else{$stmt=$pdo->query('SELECT * FROM shipments ORDER BY created_at DESC');}
 $rows=$stmt->fetchAll(); $stats=['total'=>count($rows),'pending'=>0,'transit'=>0,'delivered'=>0]; foreach($rows as $r){if($r['status']==='Pending')$stats['pending']++;elseif($r['status']==='In Transit')$stats['transit']++;elseif($r['status']==='Delivered')$stats['delivered']++;}
 json_response(['success'=>true,'shipments'=>$rows,'stats'=>$stats]);
}
if($method==='PATCH'){
 require_admin(); $d=input(); $id=(int)($d['id']??0); $status=(string)($d['status']??'');
 if($id<1||!in_array($status,['Pending','In Transit','Delivered'],true)) json_response(['success'=>false,'message'=>'Invalid shipment or status.'],422);
 $stmt=$pdo->prepare('UPDATE shipments SET status=?,updated_at=CURRENT_TIMESTAMP WHERE id=?');$stmt->execute([$status,$id]);json_response(['success'=>true,'status'=>$status]);
}
if($method==='DELETE'){
 require_admin(); $id=(int)($_GET['id']??0); if($id<1)json_response(['success'=>false,'message'=>'Invalid shipment ID.'],422); $stmt=$pdo->prepare('DELETE FROM shipments WHERE id=?');$stmt->execute([$id]);json_response(['success'=>true]);
}
if($method==='OPTIONS')json_response(['success'=>true]);
json_response(['success'=>false,'message'=>'Method not allowed.'],405);

<?php
declare(strict_types=1);
session_start();
$host='127.0.0.1'; $db='courier_service'; $user='root'; $pass='';
try {
 $pdo=new PDO("mysql:host=$host;dbname=$db;charset=utf8mb4",$user,$pass,[PDO::ATTR_ERRMODE=>PDO::ERRMODE_EXCEPTION,PDO::ATTR_DEFAULT_FETCH_MODE=>PDO::FETCH_ASSOC,PDO::ATTR_EMULATE_PREPARES=>false]);
} catch(PDOException $e){ http_response_code(500); header('Content-Type: application/json'); echo json_encode(['success'=>false,'message'=>'Database connection failed.']); exit; }
function json_response(array $data,int $code=200): never { http_response_code($code); header('Content-Type: application/json; charset=utf-8'); echo json_encode($data); exit; }
function require_admin(): array { if(empty($_SESSION['admin'])) json_response(['success'=>false,'message'=>'Admin login required.'],401); return $_SESSION['admin']; }

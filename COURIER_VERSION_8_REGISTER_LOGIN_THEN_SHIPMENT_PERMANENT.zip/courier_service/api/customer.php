<?php
declare(strict_types=1);
require_once __DIR__.'/db.php';
$method=$_SERVER['REQUEST_METHOD'];
function input_customer():array{ $d=json_decode(file_get_contents('php://input')?:'{}',true); return is_array($d)?$d:[]; }
if($method==='GET'){
 if(empty($_SESSION['customer_id'])) json_response(['success'=>true,'logged_in'=>false,'customer'=>null,'shipments'=>[]]);
 $stmt=$pdo->prepare('SELECT id,email FROM customers WHERE id=? LIMIT 1'); $stmt->execute([(int)$_SESSION['customer_id']]);
 $customer=$stmt->fetch(); if(!$customer){ unset($_SESSION['customer_id'],$_SESSION['customer_email'],$_SESSION['customer_token']); json_response(['success'=>true,'logged_in'=>false,'customer'=>null,'shipments'=>[]]); }
 $stmt=$pdo->prepare('SELECT tracking_id,first_name,last_name,country,state,city,delivery_address,notes,status,created_at,updated_at FROM shipments WHERE customer_id=? ORDER BY created_at DESC'); $stmt->execute([(int)$customer['id']]);
 json_response(['success'=>true,'logged_in'=>true,'customer'=>$customer,'shipments'=>$stmt->fetchAll()]);
}
if($method==='POST'){
 $d=input_customer(); $action=$d['action']??'login';
 if($action==='register'){
  $name=trim((string)($d['full_name']??''));
  $email=strtolower(trim((string)($d['email']??'')));
  $password=(string)($d['password']??'');
  if($name===''||$email===''||$password==='') json_response(['success'=>false,'message'=>'Full name, email and password are required.'],422);
  if(!filter_var($email,FILTER_VALIDATE_EMAIL)) json_response(['success'=>false,'message'=>'Please enter a valid email address.'],422);
  if(strlen($password)<6) json_response(['success'=>false,'message'=>'Password must be at least 6 characters.'],422);
  $stmt=$pdo->prepare('SELECT id FROM customers WHERE email=? LIMIT 1'); $stmt->execute([$email]);
  if($stmt->fetch()) json_response(['success'=>false,'message'=>'This email is already registered. Please sign in.'],409);
  $stmt=$pdo->prepare('INSERT INTO customers (full_name,email,password_hash) VALUES (?,?,?)');
  $stmt->execute([$name,$email,password_hash($password,PASSWORD_DEFAULT)]);
  json_response(['success'=>true,'message'=>'Account created successfully. You can now sign in.']);
 }
 if($action==='logout'){ unset($_SESSION['customer_id'],$_SESSION['customer_email'],$_SESSION['customer_token']); session_regenerate_id(true); json_response(['success'=>true]); }
 $email=strtolower(trim((string)($d['email']??''))); $password=(string)($d['password']??'');
 if($email===''||$password==='') json_response(['success'=>false,'message'=>'Email and password are required.'],422);
 $stmt=$pdo->prepare('SELECT id,full_name,email,password_hash FROM customers WHERE email=? LIMIT 1'); $stmt->execute([$email]); $u=$stmt->fetch();
 if(!$u||!password_verify($password,$u['password_hash'])) json_response(['success'=>false,'message'=>'Invalid email or password.'],401);
 session_regenerate_id(true); $_SESSION['customer_id']=(int)$u['id']; $_SESSION['customer_email']=$u['email'];
 unset($u['password_hash']); json_response(['success'=>true,'customer'=>$u]);
}
json_response(['success'=>false,'message'=>'Method not allowed.'],405);

CREATE DATABASE IF NOT EXISTS courier_service CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
USE courier_service;

CREATE TABLE IF NOT EXISTS admins (
 id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
 full_name VARCHAR(120) NOT NULL,
 email VARCHAR(190) NOT NULL UNIQUE,
 password_hash VARCHAR(255) NOT NULL,
 role ENUM('admin') NOT NULL DEFAULT 'admin',
 created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB;

CREATE TABLE IF NOT EXISTS customers (
 id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
 full_name VARCHAR(120) NOT NULL,
 email VARCHAR(190) NOT NULL UNIQUE,
 password_hash VARCHAR(255) NOT NULL,
 created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB;

CREATE TABLE IF NOT EXISTS shipments (
 id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
 tracking_id VARCHAR(30) NOT NULL UNIQUE,
 customer_token CHAR(64) NOT NULL UNIQUE,
 customer_id INT UNSIGNED NULL,
 first_name VARCHAR(80) NOT NULL,
 last_name VARCHAR(80) NOT NULL,
 phone VARCHAR(40) NOT NULL,
 country VARCHAR(80) NOT NULL,
 state VARCHAR(100) NOT NULL,
 city VARCHAR(100) NOT NULL,
 delivery_address TEXT NOT NULL,
 status ENUM('Pending','In Transit','Delivered') NOT NULL DEFAULT 'Pending',
 notes TEXT NULL,
 created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
 updated_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
 INDEX(status), INDEX(phone), INDEX(city), INDEX(customer_id),
 CONSTRAINT fk_shipments_customer FOREIGN KEY (customer_id) REFERENCES customers(id) ON DELETE SET NULL
) ENGINE=InnoDB;

-- Admin account
INSERT INTO admins(full_name,email,password_hash,role) VALUES
('Courier Administrator','muhammadmuhammad@gmail.com','$2y$12$K21hs/9dL9rtWFeIxfYWquGpIv1iYtivmFcbwoMvXa31wAR9B58qe','admin')
ON DUPLICATE KEY UPDATE email=VALUES(email);

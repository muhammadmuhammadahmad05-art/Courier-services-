<?php
declare(strict_types=1);
require_once __DIR__.'/api/db.php';
if(empty($_SESSION['customer_id'])){ header('Location: register.php'); exit; }
?>
<!doctype html><html lang="en"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>SwiftDrop Courier — Dashboard</title><link rel="stylesheet" href="assets/style.css?v=11"></head><body>
<div class="app-shell">
<aside class="sidebar"><div class="brand"><div class="brand-mark">S</div><div><strong>SwiftDrop</strong><span>Courier Services</span></div></div><nav><a class="active nav-dashboard" href="dashboard.php#create">▦ <span>Dashboard</span></a><a href="user_login.php" class="user-login">👤 <span>User Login</span></a></nav><div class="sidebar-bottom"><div class="support"><span>●</span><div><b>System Online</b><small>Local server ready</small></div></div><a href="admin.php" class="admin-link">Admin Login</a></div></aside>
<main class="main"><header class="topbar"><div><div class="eyebrow">COURIER SERVICE</div><h1>Create New Shipment</h1></div><div class="top-actions"><span class="date" id="today"></span></div></header>
<section id="create" class="panel form-panel"><div class="panel-head"><div><h2>Create New Shipment</h2><p>Enter the receiver and delivery information below. You must be signed in to create a shipment.</p></div><span class="badge">● Secure</span></div>
<form id="shipmentForm"><div class="section-label">Receiver Information</div><div class="form-grid three"><label>First Name<input name="first_name" required placeholder="e.g. Ahmad"></label><label>Last Name<input name="last_name" required placeholder="e.g. Musa"></label><label>Phone Number<input name="phone" required type="tel" placeholder="+234 800 000 0000"></label></div>
<div class="account-strip"><span>ACCOUNT</span><strong><?php echo htmlspecialchars((string)($_SESSION['customer_email'] ?? ''), ENT_QUOTES, 'UTF-8'); ?></strong><small>You are signed in. This shipment will be saved to your account.</small></div>
<div class="section-label">Delivery Location</div><div class="form-grid three"><label>Country<select id="country" name="country" required></select></label><label>State / Province<select id="state" name="state" required></select></label><label>City<select id="city" name="city" required></select></label></div>
<label>Delivery Address<textarea name="delivery_address" required placeholder="Street, house number, landmark, area..."></textarea></label><label>Delivery Notes <input name="notes" placeholder="Optional instructions"></label>
<div class="form-footer"><span id="formMessage"></span><button id="shipmentButton" class="primary" type="submit" disabled>Create Shipment →</button></div></form></section>

</main></div><script src="assets/app.js"></script></body></html>

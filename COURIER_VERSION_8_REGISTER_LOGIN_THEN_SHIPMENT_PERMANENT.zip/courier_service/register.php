<!doctype html>
<html lang="en">
<head>
<meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1">
<title>SwiftDrop — Register</title>
<link rel="stylesheet" href="assets/style.css?v=11">
</head>
<body>
<div class="app-shell">
<aside class="sidebar"><div class="brand"><div class="brand-mark">S</div><div><strong>SwiftDrop</strong><span>Courier Services</span></div></div><nav><a class="nav-dashboard" href="index.php">⌂ <span>Home</span></a><a class="active user-login" href="register.php">👤 <span>Register</span></a><a href="user_login.php" class="user-login">↪ <span>User Login</span></a></nav><div class="sidebar-bottom"><div class="support"><span>●</span><div><b>System Online</b><small>Customer registration</small></div></div><a href="admin.php" class="admin-link">Admin Login</a></div></aside>
<main class="main"><header class="topbar"><div><div class="eyebrow">CUSTOMER REGISTRATION</div><h1>Create Your Account</h1></div><div class="top-actions"><span class="date" id="today"></span></div></header>
<section class="panel form-panel" style="max-width:650px;margin:20px auto"><div class="panel-head"><div><h2>Register an account first</h2><p>Create your SwiftDrop customer account before creating shipments or using customer services.</p></div><span class="badge">● Secure</span></div>
<form id="registerForm"><div class="form-grid one"><label>Full Name<input id="registerName" type="text" required autocomplete="name" placeholder="e.g. Ahmad Musa"></label></div><div class="form-grid two"><label>Email<input id="registerEmail" type="email" required autocomplete="email" placeholder="you@example.com"></label><label>Password<input id="registerPassword" type="password" required minlength="6" autocomplete="new-password" placeholder="At least 6 characters"></label></div><div class="form-grid one"><label>Confirm Password<input id="registerConfirm" type="password" required minlength="6" autocomplete="new-password" placeholder="Re-enter your password"></label></div><div class="form-footer"><span id="registerMessage"></span><button class="primary" type="submit">Create Account →</button></div></form><div class="register-prompt">Already have an account? <a href="user_login.php">Sign in here</a></div></section>
</main></div>
<script>
const form=document.getElementById('registerForm'); const msg=document.getElementById('registerMessage');
form.addEventListener('submit',async e=>{e.preventDefault(); msg.textContent='Creating account...'; msg.className=''; const p=document.getElementById('registerPassword').value, c=document.getElementById('registerConfirm').value; if(p!==c){msg.textContent='Passwords do not match.';msg.className='error-text';return;} try{const r=await fetch('api/customer.php',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({action:'register',full_name:document.getElementById('registerName').value.trim(),email:document.getElementById('registerEmail').value.trim(),password:p})}); const d=await r.json(); if(!d.success) throw Error(d.message); msg.textContent=d.message; msg.className='success-text'; form.reset(); setTimeout(()=>location.href='user_login.php?registered=1',900);}catch(err){msg.textContent=err.message;msg.className='error-text';}});
document.getElementById('today').textContent=new Date().toLocaleDateString(undefined,{weekday:'short',month:'short',day:'numeric',year:'numeric'});
</script></body></html>

const $=s=>document.querySelector(s); const esc=v=>String(v??'').replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
function statusClass(status){return status==='Delivered'?'delivered':status==='In Transit'?'in-transit':'pending';}
function card(s){return `<div class="customer-shipment-card"><div class="shipment-main"><div class="tracking-label">TRACKING ID</div><strong>${esc(s.tracking_id)}</strong><div class="shipment-location">${esc(s.city)}, ${esc(s.state)} • ${esc(s.country)}</div></div><span class="shipment-status ${statusClass(s.status)}">${esc(s.status)}</span></div>`}

function showLoggedOut(message=''){
  $('#userLoginForm').classList.remove('hidden');
  $('#userStatus').classList.add('hidden');
  $('#userLoginForm').reset();
  const m=$('#userLoginMessage');
  m.textContent=message;
  m.className=message?'success-text':'';
}

async function load(){
 const r=await fetch('api/customer.php',{cache:'no-store'}); const d=await r.json();
 if(!d.logged_in){showLoggedOut(); return;}
 // Once login succeeds, remove the credentials form from view.
 $('#userLoginForm').classList.add('hidden');
 $('#userLoginMessage').textContent='';
 $('#userStatus').classList.remove('hidden');
 $('#userStatus').innerHTML=`<div class="customer-header"><div><span class="eyebrow">SIGNED IN</span><h3>My Shipments</h3><p class="account-email">${esc(d.customer.email)}</p></div><button id="customerLogout" class="logout-btn" type="button">Log out</button></div>${d.shipments.length?d.shipments.map(card).join(''):'<p class="empty">No shipments found for this email.</p>'}`;
 $('#customerLogout').addEventListener('click',logout);
}

async function logout(){
 await fetch('api/customer.php',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({action:'logout'})});
 showLoggedOut('You have been logged out.');
}

$('#userLoginForm').addEventListener('submit',async e=>{
 e.preventDefault();
 const m=$('#userLoginMessage');
 m.textContent='Signing in...';m.className='';
 try{
  const r=await fetch('api/customer.php',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({action:'login',email:$('#userEmail').value.trim(),password:$('#userPassword').value})});
  const d=await r.json();
  if(!d.success)throw Error(d.message);
  // Hide credentials immediately after a successful login.
  $('#userLoginForm').classList.add('hidden');
  $('#userLoginMessage').textContent='';
  window.location.href='dashboard.php';
 }catch(e){m.textContent=e.message;m.className='error-text';}
});
$('#today').textContent=new Date().toLocaleDateString(undefined,{weekday:'short',month:'short',day:'numeric',year:'numeric'});
load();

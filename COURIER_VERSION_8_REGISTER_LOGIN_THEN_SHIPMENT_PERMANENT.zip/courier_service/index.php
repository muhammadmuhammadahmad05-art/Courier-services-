<!doctype html>
<html lang="en">
<head>
<meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1">
<title>SwiftDrop Courier — Welcome</title>
<link rel="stylesheet" href="assets/style.css?v=9">
</head>
<body class="landing-body">
<div class="landing-shell">
  <header class="landing-nav">
    <a class="landing-brand" href="index.php"><span class="brand-mark">S</span><span><strong>SwiftDrop</strong><small>Courier Service</small></span></a>
    <div class="landing-nav-actions"><a class="landing-text-link" href="user_login.php">User Login</a><a class="landing-admin-link" href="admin.php">Admin Login</a></div>
  </header>

  <section class="portal-brand" aria-label="SwiftDrop Courier Service Portal">
    <div class="portal-logo-row">
      <svg class="portal-box-logo" viewBox="0 0 170 120" aria-hidden="true">
        <path d="M18 58 76 30l53 27-57 29z" fill="#0c4a91"/>
        <path d="M18 58v39l54 25V86z" fill="#123f83"/>
        <path d="M72 86v36l57-29V57z" fill="#0b57a3"/>
        <path d="M76 30v36l53-9" fill="#0b57a3"/>
        <path d="M91 33 73 43l34 18 18-10z" fill="#fff" opacity=".96"/>
        <path d="M136 50c12-9 23-20 29-33 2-4 7-5 9-1 3 7 0 15-5 22l-10 13c8-4 16-6 18-2 3 5-6 12-18 18-11 6-20 7-27 2z" fill="#f5a900"/>
        <path d="M139 73c12 4 24 1 35-4 6-3 10 2 6 7-8 9-22 15-40 14z" fill="#f5a900"/>
        <path d="M8 72c8-1 17 0 27 3l-8 8H7c-5 0-5-10 1-11zM7 88c10-1 18 1 28 5l-8 7H7c-5 0-5-10 0-12z" fill="#0c4a91"/>
      </svg>
      <div class="portal-wordmark"><div><span class="portal-swift">Swift</span><span class="portal-drop">Drop</span></div><strong>COURIER SERVICE PORTAL</strong></div>
    </div>
    <div class="portal-divider"><span></span><svg viewBox="0 0 48 48" aria-hidden="true"><path d="M9 15 24 7l15 8-15 8zM9 15v18l15 9V23M39 15v18l-15 9M24 23v19M17 11l15 8M31 12l-14 8" fill="none" stroke="#f5a900" stroke-width="2.8" stroke-linejoin="round"/><path d="M24 8v8" stroke="#f5a900" stroke-width="2.8"/></svg><span></span></div>
  </section>

  <main class="landing-main">
    <section class="hero-copy">
      <span class="hero-kicker">FAST • SAFE • RELIABLE DELIVERY</span>
      <h1>Move your<br>packages<br><span>with confidence.</span></h1>
      <p>SwiftDrop makes it simple to create shipments, manage deliveries, and keep track of your packages from one secure courier service portal.</p>
      <div class="hero-actions"><a class="landing-primary" href="register.php">Register an Account <span>→</span></a><a class="landing-secondary" href="user_login.php">Sign in to your account</a></div>
      <div class="hero-points"><span>✓ Fast &amp; Reliable Delivery</span><span>✓ Easy Tracking</span><span>✓ Secure delivery management</span></div>
    </section>
    <section class="hero-visual" aria-label="Courier service overview">
      <div class="visual-glow"></div>
      <div class="delivery-card"><div class="delivery-top"><span class="mini-label">SHIPMENT STATUS</span></div><div class="route"><div class="route-node"><b>Pickup</b><small>Lagos</small></div><div class="route-line"><span></span><i>✈</i><span></span></div><div class="route-node right"><b>Delivery</b><small>Abuja</small></div></div><div class="tracking-box"><small>TRACKING ID</small><strong>SD-2026-04821</strong><span>In Transit</span></div></div>
      <div class="feature-float feature-one"><span>↗</span><div><b>Fast Delivery</b><small>Built for everyday shipments</small></div></div>
      <div class="feature-float feature-two"><span>♢</span><div><b>Secure Service</b><small>Your items are safe with us</small></div></div>
    </section>
  </main>
</div>
</body>
</html>
# Test Checklist

## Customer
1. Open the customer page.
2. Confirm the first/main action is Create New Shipment.
3. Confirm there is no Operations Dashboard and no Recent Shipments table.
4. Fill first name, last name, phone, country, state, city, address and optional notes.
5. Click Ship Shipment.
6. Confirm a Tracking ID appears and status is Pending.
7. Refresh the page and confirm only that browser session's shipment status is shown.

## Admin
1. Open /admin.php.
2. Login with muhammadmuhammad@gmail.com / password.
3. Confirm all submitted shipments and Tracking IDs are visible.
4. Change a shipment to Pending, In Transit or Delivered.
5. Confirm the status is saved after refresh.
6. Delete a shipment and confirm it disappears.

## Security expectation
Customer requests do not receive the admin shipment list. Status update and deletion endpoints require an authenticated admin session.
